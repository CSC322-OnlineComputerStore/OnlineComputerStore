def get_order(filename):

    l=[]
    k=[]
    m=[]
    with open(filename, "r") as myfile:
       lines=myfile.read().split(",")
        l.append(lines)
    for i in range(len(l)):
        k+=l[i]
    m=[k[i:i+8] for i in range (0, len(k),8)]
    l=[k[i:i+8] for i in range (0, len(k),8)]
    l[2 : 7] = [",".join(l[2 : 7])]

    print(l)