def get_order(filename):
    l=[]
    k=[]
    m=[]
    n=[]
    with open(filename, "r") as myfile:
        lines=myfile.read().split(",")
        l.append(lines)
    for i in range(len(l)):
        k+=l[i]
    l=[k[i:i+5] for i in range (0, len(k),5)]
    for i in range(len(l)):
        if(l[i][len(l[i])-1]=="0"):
            for j in range(len(l[i])-1):
                if (j==0):
                    l[i][j]=l[i][j].replace('\n','')
                m.append(l[i][j])
    n=[m[i:i+4] for i in range (0, len(m),4)]
    print(n)
filename='1122350'
get_order(filename)
