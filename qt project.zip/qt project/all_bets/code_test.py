def get_order(filename):
    k=[]
    l=[]
    #bet=self.ui.bet_enter.text()
    bet="14"
    company="delivery"
    with open(filename, "r") as myfile:
        lines=myfile.readlines()
        l.append(lines)
    print(lines)
    for i in range(len(l)):
        if (i==(len(l)-1)):
            l[i]+="\n"
        k+=l[i]
        
    if not("." in bet):
        bet=bet+".00"
    k.append(bet+" "+company)
    
    #k.append(company)
    l=[k[i:i+2] for i in range (0, len(k),2)]
    print(k)
    print(l)
    with open(filename,"w") as file:
        file.writelines(k)
        file.close()

filename='1122350'
get_order(filename)
