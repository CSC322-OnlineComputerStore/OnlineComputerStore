def get_order(filename):
    k=[]
    l=[]
    #bet=self.ui.bet_enter.text()
    bet="14"
    company="delivery"
    with open(filename, "r") as myfile:
        lines=myfile.readlines()
        l.append(lines)
    print(l[0][1])

filename='00001'
get_order(filename)
